
public interface IVerifyProperty {
	boolean hasPropery(int a);
}
