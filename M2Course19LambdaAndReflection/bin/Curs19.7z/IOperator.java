
public interface IOperator {
	int operation(int a, int b);
}
