
public class Exercise2 {

		/*Fara implementarea unor clase suplimentare abstractizarea nu este posibila,
		 * pentru ca execitiul se axeaza pe compunere si agregare, nu pe mostenire.
		 * 
		 *  Ar putea fi folosita abstractizarea in cazul in care am avea o clasa generala
		 *  Smartphone care extinde alte clase specifice (Samsung, Huawei etc).
		 */
}
