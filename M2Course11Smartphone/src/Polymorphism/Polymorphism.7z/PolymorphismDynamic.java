package Polymorphism;

public class PolymorphismDynamic {
	
	public void infoToPrint() {
		System.out.println("Class => PolymorphismDynamic");
	}
}
