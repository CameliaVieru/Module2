package Polymorphism;

public class PolymorphismDynamic2 extends PolymorphismDynamic{
	
	@Override
	public void infoToPrint() {
		System.out.println("Class => PolymorphismDynamic 2");
	}
}
